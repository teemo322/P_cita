<?php
// Datos
$token = 'apis-token-1.aTSI1U7KEuT-6bbbCguH-4Y8TI6KS73N';
$dni = $_REQUEST['Expediente'];

// Iniciar llamada a API
$curl = curl_init();

// Buscar Expediente
curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://api.apis.net.pe/v1/Expediente?numero=' . $Expediente,
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 2,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'GET',
  CURLOPT_HTTPHEADER => array(
    'Referer: https://apis.net.pe/consulta-Expediente-api',
    'Authorization: Bearer ' . $token
  ),
));

$response = curl_exec($curl);
echo $response;


// curl_close($curl);
// // Datos listos para usar
// $persona = json_decode($response);
// var_dump($persona);
?>